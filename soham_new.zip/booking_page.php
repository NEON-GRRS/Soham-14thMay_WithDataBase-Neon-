<?php include('register.php');?>
<?php include('process.php');?>
<?php 

//index.php

//include('database_connection.php');
include('database_connection.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="css/booking.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
    <link rel="stylesheet" href="footer.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>


 <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-ui.js"></script>
   
 
    <link href = "css/jquery-ui.css" rel = "stylesheet">

<!--link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css"-->
<!--script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>


 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"-->
 
<style type="text/css">
  
.button {
  background-color: white; 
  color: #008CBA; 
  border: 2px solid #008CBA;
  border-radius: 5px;
  width: 150px;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
  transform: translateY(-20%);
  border:2px ;
  box-shadow:2px 5px grey;
}
#demo{
  border:2px solid;
  background-color: white;
  padding-left:15px;
  border-radius:20px;
  color: blue;
  height:;
  box-shadow: 5px 10px blue;
}
.about-section{
  background-color: #ffff80;
}

.navbar-lite{
  background-color:#ffff80;
}
</style>





























     
  </head>
  <body>
    <!------------------------------navbar------------------------------------>
<div class="bgimg navbar-lite ">
      <nav class="navbar navbar-expand-md navbar-custom navbar-lite bg-dark navbar-dark fixed-top ">
       <!-- Brand -->
        <a class="navbar-brand" href="#"><img src="image/img11.jfif" alt="logo" width="70px"></a>

       <!-- Toggler/collapsibe Button -->
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
       </button>

        <!-- Navbar links -->
       <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <?php session_start();
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="home.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">Home</a>';
            }
            else
            {
               echo '<a class="nav-link" href="home.php">Home</a>';
            }
            ?>
           </li>
            <li class="nav-item">
              <?php
              if(isset($_SESSION['name']) && isset($_SESSION['email'])){
              echo '<a class="nav-link" href="aboutus.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">About Us</a>';
            }
            else
            {
               echo '<a class="nav-link" href="aboutus.php">About us</a>';
            }
            ?>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Booking History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gallery</a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Top Destinations
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Kolkata</a>
              <a class="dropdown-item" href="#">Asansol</a>
              <a class="dropdown-item" href="#">bhubaneswar</a>
            </div>
          </li>
          
          <?php 
          if(!isset($_SESSION['name']) && !isset($_SESSION['email'])){
            echo'<li class="nav-item dropdown">

            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
              Login/Signup
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#" data-target="#mymodel1" data-toggle="modal">Sign Up</a>
              <a class="dropdown-item" href="#" data-target="#mymodel" data-toggle="modal">Login</a>
              
            </div>
            </li>';
          }
          else
          {
          }
           ?>
          
             <li class="nav-item dropdown">
                 <?php
                  
                    if(isset($_SESSION['name']) && isset($_SESSION['email']))
                    {
                       echo '<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                            Your Account
                             </a>';
                              echo '<div class="dropdown-menu">';
                               echo '<a class="dropdown-item" href="user_profile.php?name='.$_SESSION['name'].'&email='.$_SESSION['email'].'">'.$_SESSION['name'].'</a>';
                                  echo '<a class="dropdown-item" href="logout.php?logout">Logout</a>';

              
                                   echo '</div>';
                    }
                 
             
                    ?>
          </li>
          <!--<li class="nav-item mgr-autos" >
            <a class="nav-link" href="#">Log in</a>
          </li>-->
           
      </ul>
              
    </div>
    </nav>
  
</div>

<!--------navbar end------>
<!---------------------------------------- Login / SIgn up -------------------------------------->

<!---------------------------------------- Login / SIgn up -------------------------------------->


<div class="container">
    <div class="modal" id="mymodel">
      <div class="modal-dialog ">
        
        <div class="modal-content">
                <div class= "modal-header">
                    <button type="button" class="close" data-dismiss="modal"> &times;</button>
                </div>
        
            <div class="modal-body">
         
        
                      <center><h3 class="text-primary">Login</h3></center>
                      <center><p style="font-size:20px">Login Using Social accounts</p></center> 

            
                      <center>
                         <label><a href="#" class="fa fa-facebook"></a>
                          <a href="#" class="fa fa-twitter"></a>
                          <a href="#" class="fa fa-google"></a></label>
                      </center>
            
                           &nbsp;&nbsp;&nbsp;
                      <center><p style="font-size:20px">or</p></center> 
          
                    <form id="mylogin" method="post" action="aboutus.php">
                       
                      <div class="form-group">
                        <input type="email" name="uemail" placeholder="Email" class="form-control" required />

                      </div>
                      <div class="form-group">
                         <input type="password" name="upassword" placeholder="Password" class="form-control" required />

                      </div>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div class="checkbox">
                         <label><input type="checkbox" value="">Remember me</label>
                          &nbsp;&nbsp;

                       <a href="#" class="btn btn-link">Forget password?</a> 
                       </div>
                      <div class="modal-footer justify-content-center">
                       <input type="submit" class="btn btn-success" name="login" value="Login">
                      </div>
            
                    </form>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            
            </div>
        </div>
            </div>
          


          </div>

      </div>

  




<div class="container">
    <div class="modal" id="mymodel1">
      <div class="modal-dialog ">
        
        <div class="modal-content">
          <div class= "modal-header">
          <button type="button" class="close" data-dismiss="modal"> &times;</button>
        </div>
        
            <div class="modal-body">

              <center><h3 class="text-primary">Signup</h3></center>
              <center><p style="font-size:20px">Create your account</p></center> 

              

            <form id="mysignup" method="post" action="aboutus.php">
              <div class="form-group">
                <input type="text" name="name" placeholder="Full name" class="form-control" required />

              </div>
              
              <div class="form-group">
                <input type="email" name="email" placeholder="Email" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control" required />

              </div>
              <div class="form-group">
                <input type="text" name="mobno" placeholder="Mobile No" class="form-control" required />

              </div>
             
                <div class="form-group">

                <input type="date" name="dob" placeholder="DoB(dd\mm\yy)" class="form-control" required />

              </div>

          

              <center><div class="g-recaptcha" data-sitekey="6LeVOvIUAAAAAK_9Pzhoa-KkS2XzQjcz1gUJDFIB" required>
          
             </div></center>
              <div class="modal-footer justify-content-center">
              <input type="submit" class="btn btn-danger"  name="signup" value="Signup">
            </div>
            </form>
            
          </div>
            </div>
          


          </div>
        


        </div>


      </div>

  
      

  </div>

<!--------------------------------------booking-------------------------->

<div class="about-section">

<br /><br /><br /><br />



  <div class="row container">
         
      <div class="col-md-3">  

        <button data-toggle="collapse" data-target="#demo" class="button button2">Filters And More</button>

        <div id="demo" class="collapse">

          <!---open thiss-----
 
           <div id="mySidebar" class="sidebar">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    
           <ul>----->
            <br />
            <br />
         <div class="list-group">
             <h6>Price</h6>
             <input type="hidden" id="hidden_minimum_price" value="2000" />
             <input type="hidden" id="hidden_maximum_price" value="65000" />
             <p id="price_show">2000 - 65000</p>
            <div id="price_range" style="width: 200px;">
                      
            </div>
         </div> <br>
        <div class="list-group">
             <h6>Hotel  Type</h6>
             <div style="height: 180px; overflow-y: auto; overflow-x: hidden; width: 200px;">
                 <?php

                    $query = "SELECT DISTINCT(hotel_type) FROM hotel  ORDER BY hotel_id DESC";
                    $statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    /*$result=mysqli_query($db,$query);
                    /*$result= mysqli_fetch_array($result);*/
                    foreach($result as $row)
                   /* while($row= mysqli_fetch_array($result))*/
                    {
                    ?>
                    <div class="list-group-item checkbox" style="height:50px;">
                        <label><input type="checkbox" class="common_selector hotel_type" value="<?php echo $row['hotel_type']; ?>"  > <?php echo $row['hotel_type']; ?></label>
                    </div>
                    <?php
                    }

                    ?>
             </div>
        </div>
                
                <br/>
        <div class="list-group">
          <h6>User Rating</h6>
                     <div style="height: 180px; overflow-y: auto; overflow-x: hidden;width: 200px;">
                    <?php

                    $query = "
                    SELECT DISTINCT(hotel_rating) FROM hotel  ORDER BY hotel_id DESC
                    ";

                    /* $result=mysqli_query($db,$query);
                    while($row= mysqli_fetch_array($result))*/
                         $statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    foreach($result as $row)
                    {
                    ?>
                    <div class="list-group-item checkbox" style="height:50px;">
                        <label><input type="checkbox" class="common_selector hotel_rating" value="<?php echo $row['hotel_rating']; ?>" > <?php echo $row['hotel_rating']; ?> 
                    *</label>
                    </div>
                    <?php    
                    }

                    ?>
                </div>
            </div>
                   
            <br>
            
            <div class="list-group">
                    <h6>Amenities</h6>
                     <div style="height: 180px; overflow-y: auto; overflow-x: hidden;width: 200px;">
                    <?php

                    $query = "
                    SELECT DISTINCT(amenities_name) FROM amenities  ORDER BY am_id DESC
                    ";

                    /* $result=mysqli_query($db,$query);
                    while($row= mysqli_fetch_array($result))*/
                         $statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    foreach($result as $row)
                    {
                    ?>
                    <div class="list-group-item checkbox" style="height:50px;">
                        <label><input type="checkbox" class="common_selector amenities_name" value="<?php echo $row['amenities_name']; ?>" > <?php echo $row['amenities_name']; ?> 
                    </label>
                    </div>
                    <?php    
                    }

                    ?>
                </div>
            </div>


            <br>







                <div class="list-group">
                    <h6>Hotel  Chain</h6>
                    <div style="height: 180px; width: 200px;">
                    <?php

                    $query = "SELECT DISTINCT(hotel_chain) FROM hotel  ORDER BY hotel_id DESC";
                    /*$statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();*/
                   /* $result=mysqli_query($db,$query);*/
                    /*$result= mysqli_fetch_array($result);
                    foreach($result as $row)*/
                   // while($row= mysqli_fetch_array($result))
                                   $statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();
                    foreach($result as $row)
                    {
                    ?>
                    <div class="list-group-item checkbox" style="height:50px;">
                        <label><input type="checkbox" class="common_selector hotel_chain" value="<?php echo $row['hotel_chain']; ?>"  > <?php echo $row['hotel_chain']; ?></label>
                    </div>
                    <?php
                    }

                    ?>
                    </div>
                </div>
                <br>
                <br>
            </div>
            

     </div>
     
<br>


            <div class="col-md-9">
              <br  />
              <br />
                <div class="row filter_data">

                </div>
            </div>
        </div> 
    </div>
</div>
  









<!--------------------------------------------- footer----------------------------------->
    <div class="footer">
        <div class="inner-footer">
            <div class="footer-items">
                <h1 class="footer-h1">NEON</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.</p>
            </div>
        <div class="footer-items">
            <h2 class="footer-h2">Quick Links</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Home</li></a>
                <a href=""><li>About Us</li></a>
                <a href=""><li>Contact Us</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Services</h2>
            <div class="border-footer"></div>
            <ul>
                <a href=""><li>Hotels</li></a>
                <a href=""><li>Paying Guests</li></a>
                <a href=""><li>Car Rentals</li></a>
            </ul>
        </div>
        <div class="footer-items">
            <h2 class="footer-h2">Contact Us</h2>
            <div class="border-footer"></div>
            <ul>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>XYZ Street, Kolkata</li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>1234567896</li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i>support@neon.com</li>
            </ul>
        </div>
        <div class="social-media">
                <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        </div>
    </div>
    <div class="footer-bottom">
        Copyright &copy; Neon 2020. All rights reserved.
    </div>
</div>








<!--------------------------test-card-js-------------------->

<!--script src="js/jquery.js"></script-->
<!--------------------------test-card-js-------------------->
<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script-->

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>





<script type="text/javascript" src="js/booking.js"></script>


<script>
$(document).ready(function(){

    filter_data();

    function filter_data()
    {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var hotel_type = get_filter('hotel_type');
        var hotel_rating = get_filter('hotel_rating');
       var amenities_name = get_filter('amenities_name');
         var hotel_chain = get_filter('hotel_chain');
        

        $.ajax({
            url:"fetch_data.php",
            method:"POST",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price, hotel_type:hotel_type, hotel_rating:hotel_rating,  hotel_chain:hotel_chain,amenities_name:amenities_name},
            success:function(data){
                $('.filter_data').html(data);
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:2000,
        max:65000,
        values:[2000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>






  </body>
</html>
