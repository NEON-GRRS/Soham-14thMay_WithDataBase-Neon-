-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2020 at 01:59 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `neon`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `book_id` varchar(255) NOT NULL,
  `room_id` varchar(255) NOT NULL,
  `book_to` date NOT NULL,
  `book_fr` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `hotel_id` varchar(255) NOT NULL,
  `hotel_name` varchar(500) NOT NULL,
  `hotel_pic` varchar(500) NOT NULL,
  `hotel_type` varchar(500) NOT NULL,
  `hotel_rating` int(11) NOT NULL,
  `total_rooms` int(11) NOT NULL,
  `hotel_add` varchar(500) NOT NULL,
  `hotel_loc` varchar(500) NOT NULL,
  `hotel_price` int(11) NOT NULL,
  `hotel_amenities` varchar(1000) NOT NULL,
  `hotel_chain` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotel_id`, `hotel_name`, `hotel_pic`, `hotel_type`, `hotel_rating`, `total_rooms`, `hotel_add`, `hotel_loc`, `hotel_price`, `hotel_amenities`, `hotel_chain`) VALUES
('h01', 'Amar Bangla', 'image/H1.jpg', '7 Star', 3, 500, '8c gdgldvk', 'Kolkata', 5000, 'Spa,Wi-fi,Breakfast,Swimming pool', 'Neon'),
('h02', 'Ghor Banglo', 'image/H2.jpg', '3 Star', 5, 1000, 'ghyjiuhngfhdgrtryh', 'Howrah', 2000, 'Swimming pool', 'Dada'),
('h03', 'Novotel', 'image/H3.jpg', '10 Star', 5, 2000, 'ausdytgQHJUSKHBGCFVY', 'Kolkata', 15000, 'Spa,Swimming pool,Wi-fi,Breakfast,Unisex gym,Bar', 'Navotel'),
('h04', 'ITC Royal', 'image/H4.jpg', '7 Star', 4, 5000, 'fg,mnbhvcgfd', 'Mumbai', 18000, 'Spa,Bar,Wi-fi', 'ITC'),
('h05', 'ITC Golden Palace', 'image/H5.jpg', '10 Star', 5, 8000, 'sfasdfds', 'Delhi', 55000, 'Wi-fi', 'ITC');

-- --------------------------------------------------------

--
-- Table structure for table `pic`
--

CREATE TABLE `pic` (
  `pic_id` varchar(255) NOT NULL,
  `room_id` varchar(255) NOT NULL,
  `pic_picture` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pic`
--

INSERT INTO `pic` (`pic_id`, `room_id`, `pic_picture`) VALUES
('p01', 'ab01', 'image/H1_R1.jpg'),
('p02', 'ab01', 'image/H1_R2.jpg'),
('p03', 'ab01', 'image/H2_R1.jpg'),
('p04', 'ab01', 'image/H2_R2.jpg'),
('p05', 'gb01', 'image/H1_R1.jpg'),
('p06', 'gb01', 'image/H1_R2.jpg'),
('p07', 'ig01', 'image/H1_R1.jpg'),
('p08', 'ig01', 'image/H3_R1.jpg'),
('p09', 'ig01', 'image/H2_R2.jpg'),
('p10', 'ig02', 'image/H1_R1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `uid` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobno` varchar(255) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`uid`, `name`, `email`, `password`, `mobno`, `dob`) VALUES
(19, 'Ss', 'sd@sh.nm', 'soham', '231456', '1998-07-22'),
(20, 'ss', 'sohamsurai@gmail.com', 'ss1998', '7362435352635257652', '2020-05-07'),
(21, 'gouravG bo', 'gouravbid25@gmail.com', 'gb1997', '576265', '2020-05-07'),
(22, 'rintesh', '97rintesh.rg@gmail.com', '1234', '.8652', '2020-05-08'),
(23, 'scdvfxgbcnhm', 'sohamsurai@gmail.com', '12345', '698653', '2020-05-08');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` varchar(255) NOT NULL,
  `hotel_id` varchar(255) NOT NULL,
  `room_type` varchar(500) NOT NULL,
  `room_capacity` int(11) NOT NULL,
  `room_amenities` varchar(1000) NOT NULL,
  `room_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `hotel_id`, `room_type`, `room_capacity`, `room_amenities`, `room_price`) VALUES
('ab01', 'h01', 'Double Room', 2, 'Kitchen,Balcony', 5000),
('gb01', 'h02', 'King Room', 3, 'Kitchen,Balcony,AC,Laundry', 3000),
('gb02', 'h02', 'Deluxe Room', 2, 'Kitchen,Balcony', 4000),
('ig01', 'h05', 'Ultimate Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance,Ease Lounge,Mini Bar', 55000),
('ig02', 'h05', 'California King Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance, Dining Space,Ease Lounge,Mini Bar', 57000),
('ir01', 'h04', 'Superior Room', 3, 'Laundry,AC,Balcony,24 hrs assistance, Dining Space,Ease Lounge', 27000),
('ir02', 'h04', 'Queen Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance', 21000),
('ir03', 'h04', 'Queen Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance', 21000),
('ir04', 'h04', 'Single Room', 1, 'Laundry,AC,Balcony', 18000),
('nav01', 'h03', 'Queen Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance, Dining Space', 18000),
('nav02', 'h03', 'California King Room', 2, 'Laundry,AC,Balcony,Side view,24 hrs assistance, Dining Space,Ease Lounge,Mini Bar', 30000),
('nav03', 'h03', 'King Room', 1, 'Laundry,AC,Balcony,Side view,24 hrs assistance,Mini Bar', 21000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`hotel_id`);

--
-- Indexes for table `pic`
--
ALTER TABLE `pic`
  ADD PRIMARY KEY (`pic_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `hotel_id` (`hotel_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `uid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pic`
--
ALTER TABLE `pic`
  ADD CONSTRAINT `pic_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`hotel_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
