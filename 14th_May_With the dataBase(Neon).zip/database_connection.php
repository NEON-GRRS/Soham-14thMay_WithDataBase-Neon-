<?php 

//database_connection.php

$db=mysqli_connect('localhost','root','','neon');


?>