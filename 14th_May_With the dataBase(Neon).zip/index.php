<?php 

//index.php

include('database_connection.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Product filter in php</title>

    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href = "css/jquery-ui.css" rel = "stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Page Content -->
    <div class="container">
        <div class="row">
        	<br />
        	<h2 align="center">Advance Ajax Product Filters in PHP</h2>
        	<br />
            <div class="col-md-3">                				
				<div class="list-group">
					<h3>Price</h3>
					<input type="hidden" id="hidden_minimum_price" value="2000" />
                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                    <p id="price_show">2000 - 65000</p>
                    <div id="price_range"></div>
                </div>				
                <div class="list-group">
					<h3>Hotel  Type</h3>
                    <div style="height: 180px; overflow-y: auto; overflow-x: hidden;">
					<?php

                    $query = "SELECT DISTINCT(hotel_type) FROM hotel  ORDER BY hotel_id DESC";
                    /*$statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();*/
                    $result=mysqli_query($db,$query);
                    /*$result= mysqli_fetch_array($result);
                    foreach($result as $row)*/
                    while($row= mysqli_fetch_array($result))
                    {
                    ?>
                    <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="<?php echo $row['hotel_type']; ?>"  > <?php echo $row['hotel_type']; ?></label>
                    </div>
                    <?php
                    }

                    ?>
                    </div>
                </div>

				<div class="list-group">
					<h3>User Rating</h3>
                    <?php

                    $query = "
                    SELECT DISTINCT(hotel_rating) FROM hotel  ORDER BY hotel_id DESC
                    ";
                     $result=mysqli_query($db,$query);
                    while($row= mysqli_fetch_array($result))
                    {
                    ?>
                    <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector ram" value="<?php echo $row['hotel_rating']; ?>" > <?php echo $row['hotel_rating']; ?> 
                    *</label>
                    </div>
                    <?php    
                    }

                    ?>
                </div>
				
				<div class="list-group">
					<h3>Amenities</h3>
                    <div class="list-group-item checkbox">
    					<input type="checkbox" class="checkcustom" name="ammenities" value="Breakfast"> &nbsp Introductory Breakfast <br>
                       <input type="checkbox" class="checkcustom" name="ammenities" value="spa">&nbsp Spa<br>
                       <input type="checkbox" class="checkcustom" name="ammenities" value="Swimming pool">&nbsp Swimming pool<br>
                       <input type="checkbox" class="checkcustom" name="ammenities" value="Kitchen">&nbsp Kitchen<br>
                       <input type="checkbox" class="checkcustom" name="rammenities" value="Wi-fi">&nbsp Wi-fi<br>
                       <input type="checkbox" class="checkcustom" name="ammenities" value="Air_conditioned">&nbsp Air Conditioned<br>
                       <input type="checkbox" class="checkcustom" name="ammenities" value="Air_conditioned">&nbsp Air Conditioned<br>
                   </div>
                </div>
            
                <div class="list-group">
                    <h3>Hotel  Chain</h3>
                    <div style="height: 180px; overflow-y: auto; overflow-x: hidden;">
                    <?php

                    $query = "SELECT DISTINCT(hotel_chain) FROM hotel  ORDER BY hotel_id DESC";
                    /*$statement = $connect->prepare($query);
                    $statement->execute();
                    $result = $statement->fetchAll();*/
                    $result=mysqli_query($db,$query);
                    /*$result= mysqli_fetch_array($result);
                    foreach($result as $row)*/
                    while($row= mysqli_fetch_array($result))
                    {
                    ?>
                    <div class="list-group-item checkbox">
                        <label><input type="checkbox" class="common_selector brand" value="<?php echo $row['hotel_chain']; ?>"  > <?php echo $row['hotel_chain']; ?></label>
                    </div>
                    <?php
                    }

                    ?>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
            	<br />
                <div class="row filter_data">

                </div>
            </div>
        </div>

    </div>
<style>
#loading
{
	text-align:center; 
	background: url('loader.gif') no-repeat center; 
	height: 150px;
}
</style>

<script>
$(document).ready(function(){

    filter_data();

    function filter_data()
    {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"fetch_data.php",
            method:"POST",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price, brand:brand, ram:ram, storage:storage},
            success:function(data){
                $('.filter_data').html(data);
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>

</body>

</html>
