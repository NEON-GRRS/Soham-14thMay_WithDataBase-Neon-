<?php

//fetch_data.php

include('database_connection.php');
//$con = new mysqli("localhost","root","","neon");
//$conn =new PDO("mysql:host=localhost;dbname:neon","root","");

if(isset($_POST['action']))
{
	$query = "SELECT * FROM hotel WHERE 1";
	if(isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"]))
	{
		$query .= "
		 AND hotel_price BETWEEN '".$_POST["minimum_price"]."' AND '".$_POST["maximum_price"]."'
		";
	}
	if(isset($_POST['hotel_type']))
	{
		$type_filter = implode("','", $_POST['hotel_type']);
		$query .= "
		 AND hotel_type IN('".$type_filter."');
		";
	}
	if(isset($_POST["hotel_rating"]))
	{
		$rating_filter = implode("','", $_POST["hotel_rating"]);
		$query .= "
		 AND hotel_rating IN('".$rating_filter."')
		";
	}
	if(isset($_POST["hotel_chain"]))
	{
		$chain_filter = implode("','", $_POST["hotel_chain"]);
		$query .= "
		 AND hotel_chain IN('".$chain_filter."')
		";
	}
	if(isset($_POST["amenities_name"]))
	{
		$am_filter = implode("','", $_POST["amenities_name"]);
		/*$query .= "
		 AND hotel_amenities IN('".$am_filter."')
		";*/
		$query .= "
		 AND hotel_id IN ( SELECT hotel_id FROM amenities  WHERE hotel.hotel_id=amenities.hotel_id AND amenities_name IN('".$am_filter."'))
		";
	}


	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total_row = $statement->rowCount();
	$output = '';

	/*$result=mysqli_query($db,$query)  or die("Error: ".mysqli_error($db));

	$row= mysqli_fetch_array($result);*/
	/*$result=$con->query($query);
	$output='';*/

	if($total_row > 0)
	{
		foreach($result as $row) 
		{
			/*$output .= '
			<div class="col-sm-4 col-lg-3 col-md-3">
				<div style="border:1px solid #ccc; border-radius:5px; padding:20px; margin-bottom:20px; height:650px; ">
					<img src="'. $row['hotel_pic'] .'" alt="" class="img-responsive" height="auto" width="auto">
					<p align="center"><strong><a href="#">'. $row['hotel_name'] .'</a></strong></p>
					<h5 style="text-align:center;" class="text-danger" >'. $row['hotel_price'] .'</h5>
					<p> '. $row['hotel_type'].' <br />
					User Rating : '. $row['hotel_rating'] .' <br />
					 '. $row['hotel_chain'] .' <br /></p>
					<p style="height:80px;text-align: center;"> '. $row['hotel_amenities'] .'  </p>
					 <center><a href="#" class="btn btn-primary">Visit more</a></center>
				</div>

			</div>
			';*/
			$output .= '
			<div class="col-sm-4 col-lg-12 col-md-6">
			
					  <div class="card"  style="border:1px solid #ccc; border-radius:10px; box-shadow: 10px 10px #888888; padding:20px; margin-bottom:20px; height:auto;">
					  	<div class="row">
					      <div class="column">
							  <div class="col-sm-4 col-md-4 col-lg-4" style="width:220px;">
									<img src="'. $row['hotel_pic'] .'" alt="" class="img-responsive" height="160px" width="180px"style="border:1px solid #ccc; border-radius:10px;"">
								</div>
						    </div>
						   <div class="column" style = "width:180px;" >
									<p align="center"><strong><a href="#"><h4 style="text-shadow: 2px 2px 2px 2px #575dff;">'. $row['hotel_name'] .'</h4></a></strong>
									('. $row['hotel_type'].')<br /></p> <br />
									User Rating : '. $row['hotel_rating'] .' <br />
									 '. $row['hotel_chain'] .' <br /></p>
									 
							</div>
							<div class="column"style="width:200px;overflow-y:auto;overflow-x:hidden;border:1px inset;">
									<p style="height:80px;text-align: center; "> Amenities:<br />'. $row['hotel_amenities'] .'  <br /></p>
							</div>
							<div class="column" style = "width:180px;">
									<h5 style="text-align:center;" class="text-danger" >Price starts from:<br />'. $row['hotel_price'] .'</h5> <br />
									 <center><a href="#" class="btn btn-primary">Visit more</a></center>
							</div>
							
						
					  </div>
			  </div>
			</div>
			';
			/*$output .= '
			<div class="col-sm-4 col-lg-3 col-md-3">
				<div class="card"  id="hotellist">
					<div class="card-body" >
  						<img class="img-responsive" src="'.$row['hotel_pic'].'" alt="Card image" height="275" width="275">
            
             			 <h4>'.$row['hotel_name'].'</h4>
              			 <p>'.$row['hotel_type'].'</p><br/>
             			<p> User Rating : '. $row['hotel_rating'] .' <br />
					 	 '. $row['hotel_chain'] .' <br />
					     '. $row['hotel_amenities'] .'  </p>
              			<p class="card-text" name="price" value="'.$row['hotel_type'].'">'.$row['hotel_price'].'</p>
              			<a href="#" class="btn btn-primary">Visit more</a>
            		</div>
            	</div>
            </div>';*/
    


		}
	}
	else
	{
		$output = '<h3>No Data Found</h3>';
	}
	echo $output;
}

?>